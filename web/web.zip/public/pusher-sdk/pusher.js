var pusher = new Pusher('af3e24d4d091be9bb173', {
    cluster: 'ap1',
    forceTLS: true
});