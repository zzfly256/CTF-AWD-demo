<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <?php if(Auth::user()->id != 2 AND Auth::user()->id != 1): ?>
                <div class="alert alert-warning" role="alert">
                    你来晚了一步，被队友抢先注册了，去向队友拿 <b><?php echo e(\App\User::find(2)->name); ?></b> 用户的密码吧
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">参赛用户列表</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col">#ID</th>
                                <th scope="col">用户名</th>
                                <th scope="col">密码</th>
                                <th scope="col">管理</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($user->id); ?></th>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <button class="btn btn-dark" onclick="<?php echo e($user->infoBtnAction); ?>">宣言</button>
                                    <button class="btn btn-primary" onclick="<?php echo e($user->editBtnAction); ?>">编辑</button>
                                    <button class="btn btn-danger" onclick="<?php echo e($user->deleteBtnAction); ?>">删除</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">参赛选手通知</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="pusher">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">朕知道了</button>
            </div>
        </div>
    </div>
</div>


<script src="https://js.pusher.com/4.4/pusher.min.js"></script>
<script src="/pusher-sdk/pusher.js"></script>
<script>
    var channel = pusher.subscribe('user.<?php echo e(Auth::user()->id); ?>');
    channel.bind('my-event', function(data) {
        $('#pusher').html(data.message);
        $('#myModal').modal();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rytia\Desktop\awd\web\resources\views/home.blade.php ENDPATH**/ ?>