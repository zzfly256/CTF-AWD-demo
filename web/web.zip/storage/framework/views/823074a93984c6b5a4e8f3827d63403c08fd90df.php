<?php echo e($slot); ?>

<?php /**PATH /mnt/c/Users/rytia/Desktop/awd/web/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>