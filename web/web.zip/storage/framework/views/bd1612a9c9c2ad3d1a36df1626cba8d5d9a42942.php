<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /mnt/c/Users/rytia/Desktop/awd/web/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>